#ifndef _LED_H_
#define _LED_H_

#include "stm32f10x.h"

#define LED_Pin GPIO_Pin_13
#define LED_RCC_CLK RCC_APB2Periph_GPIOC

void LED_GPIO_Config(void);
void LED_Change(void);

#endif
