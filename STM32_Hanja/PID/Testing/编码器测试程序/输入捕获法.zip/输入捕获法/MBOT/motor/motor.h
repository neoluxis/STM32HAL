#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"

void Set_Pwm(int PWM_Left,int PWM_Right);
int myabs(int a);


#endif

