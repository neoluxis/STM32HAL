#ifndef __TIMER_H__
#define __TIMER_H__

#include "stm32f10X.h"

void TIM1_Init(u16 arr, u16 psc);
void TIM2_Init(u16 arr, u16 psc);
void TIM3_Init(u16 arr, u16 psc);
void TIM4_Init(u16 arr, u16 psc);

#endif

