#include "sys.h"


#pragma import(__use_no_semihosting)

struct __FILE
{
	int handle;
};

FILE __stdout;
_sys_exit(int x)
{
	x = x;
}


/*�ض�������������*/
int fputc(int ch,FILE *f)
{
	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET);
	USART_SendData(USART1,(uint8_t) ch);
	return ch;
}

int fgetc(FILE *f)
{
	while(USART_GetFlagStatus(USART1,USART_FLAG_RXNE) == RESET);
	return (int)USART_ReceiveData(USART1);
}


void My_Usart1_Init(int bound)
{
	/*1.����ʱ�ӡ�GPIOAʹ��*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA,ENABLE);
	
	
	/*2.GPIO�˿�ģʽ����*/
	GPIO_InitTypeDef GPIO_InitStruct;
	/*TX*/
	GPIO_InitStruct.GPIO_Pin = Usart1_TX;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	/*RX*/
	GPIO_InitStruct.GPIO_Pin = Usart1_RX;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	//GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	
	/*3.���ڲ�����ʼ��*/
	USART_InitTypeDef USART_InitStruct;
	USART_InitStruct.USART_BaudRate = bound;//������
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//Ӳ��������
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;//USARTģʽ
	USART_InitStruct.USART_Parity = USART_Parity_No;//У��λ
	USART_InitStruct.USART_StopBits = USART_StopBits_1;//��ֹλ
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;//���ݳ���,�������żУ�������Ϊ9λ
	USART_Init(USART1, &USART_InitStruct);
	
	/*4.�����жϲ���ʼ��NVIC*/
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//���жϣ����������жϺ󣬽��յ������������жϷ�����
	
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;
	NVIC_Init(&NVIC_InitStruct);//��ʼ��NVIC
	
	/*5.ʹ�ܴ���*/
	USART_Cmd(USART1, ENABLE);
	
	/*6.��д�жϷ�����*/
	 
}

void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data)
{
  /* Check the parameters */
  assert_param(IS_USART_ALL_PERIPH(USARTx));
  assert_param(IS_USART_DATA(Data)); 
    
  /* Transmit Data */
  USARTx->DR = (Data & (uint16_t)0x01FF);
  while(USART_GetFlagStatus(USARTx,USART_FLAG_TXE)==RESET);
}

void USART_SendString(USART_TypeDef* USARTx,char* str)
{
	while((*str) != '\0')
	{
		USART_SendByte(USARTx, *str);
		str++;
	}
	while(USART_GetFlagStatus(USARTx,USART_FLAG_TC)==RESET);
}



uint16_t USART_ReceiveByte(USART_TypeDef* USARTx)
{
  /* Check the parameters */
  assert_param(IS_USART_ALL_PERIPH(USARTx));
	
  while(USART_GetFlagStatus(USARTx,USART_FLAG_RXNE)==RESET);
  
  /* Receive Data */
  return (uint16_t)(USARTx->DR & (uint16_t)0x01FF);
}


