#ifndef __MY_USART_H
#define __MY_USART_H
#include "stm32f10x.h"

#define Usart1_TX GPIO_Pin_9
#define Usart1_RX GPIO_Pin_10

void My_Usart1_Init(int bound);
void USART_SendString(USART_TypeDef* USARTx,char* str);
void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data);
uint16_t USART_ReceiveByte(USART_TypeDef* USARTx);

#endif
