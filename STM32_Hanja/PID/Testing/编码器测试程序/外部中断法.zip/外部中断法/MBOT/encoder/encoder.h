#ifndef _ENCODER_H_
#define _ENCODER_H_

#include "stm32f10x.h"
	 
void Encoder_EXTIX_Init(void);//�ⲿ�жϳ�ʼ��	
int Read_Encoder(u8 TIMX);
void Get_SpeedNow(int* CurrentVelcity_L,int* CurrentVelcity_R);

#endif

