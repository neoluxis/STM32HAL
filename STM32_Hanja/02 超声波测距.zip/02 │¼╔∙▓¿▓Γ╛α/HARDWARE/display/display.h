#ifndef __display_h
#define __display_h
#include "oled.h"
void display(u8 adiszheng,u8 adisxiao,u8 ddiszheng,u8 ddisxiao,u8 empty);
	
#endif
