#ifndef TIMER_H
#define TIMER_H
#include "sys.h"

void TIM1_PWM_Init(u16 arr,u16 psc);

void TIM3_Cap_Init(u16 arr,u16 psc);

#endif
