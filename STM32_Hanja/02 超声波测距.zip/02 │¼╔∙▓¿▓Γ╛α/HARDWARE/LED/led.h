#ifndef __LED_H
#define __LED_H

#define LED PAout(8)// PA8
#define TRIG PAout(5)//PA5

void LED_Init(void);

#endif
