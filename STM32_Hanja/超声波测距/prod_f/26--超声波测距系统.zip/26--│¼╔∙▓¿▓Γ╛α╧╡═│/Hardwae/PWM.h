#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);
void PWM_SetCompare4(uint16_t Compare);
void PWM_SetPrescaler(uint16_t Prescaler);

#endif
