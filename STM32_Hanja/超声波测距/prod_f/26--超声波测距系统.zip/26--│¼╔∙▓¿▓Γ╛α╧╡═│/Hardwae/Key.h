#ifndef __Key_H__
#define __Key_H__

void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
