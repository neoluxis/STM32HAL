#ifndef __CSB_SR04_H__
#define __CSB_SR04_H__

#include "stm32f10x.h"                  // Device header

void CSB_SR04_Init(void); //��ʼ��
float Distance(void); //����

#endif
